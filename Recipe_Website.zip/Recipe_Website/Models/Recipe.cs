﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Recipe_Website.Models
{
    public class Recipe
    {

        public int RecipeID { get; set; }
        public int PrepTime { get; set; }
        public int CookTime { get; set; }

        public string Title { get; set; }

        public string Ingredients { get; set; }

        public string Instructions { get; set; }

    }
}
